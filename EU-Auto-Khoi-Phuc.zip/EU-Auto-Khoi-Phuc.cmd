@echo off
chcp 65001 >nul
setlocal
title EU Auto - Repair update
set "EU_AUTO_ROOT=%~dp0"

echo.
echo  EU Auto - repair dashboard and updater
echo  Your Pages, schedules and AdsPower setup are kept.
echo.
echo  Please close EU Auto before continuing.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0EU-Auto-Khoi-Phuc.ps1"
if errorlevel 1 (
  echo.
  echo  Repair did not finish. Please take a photo of this window.
  pause
  exit /b 1
)

echo.
echo  Done. Open EU Auto again.
pause
