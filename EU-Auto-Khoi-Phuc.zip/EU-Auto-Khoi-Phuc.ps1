$ErrorActionPreference = 'Stop'

$root = [System.IO.Path]::GetFullPath($env:EU_AUTO_ROOT)
$app = Join-Path $root 'resources\app'
$manifestUrl = 'https://api.github.com/repos/thanhnv1493/eumedia-fb-auto-reel/contents/eumedia-update/update-manifest.json?ref=main'
$headers = @{ Accept = 'application/vnd.github+json'; 'User-Agent' = 'EU-Auto-Recovery' }

if (-not (Test-Path -LiteralPath (Join-Path $app 'server.js'))) {
  throw 'Cannot find resources\app\server.js. Extract the repair files into the folder containing EU Auto.exe, then run again.'
}

Write-Host 'Downloading the verified EU Auto repair list...'
$manifestMeta = Invoke-RestMethod -Uri $manifestUrl -Headers $headers -UseBasicParsing
if ($manifestMeta.encoding -ne 'base64' -or -not $manifestMeta.content) {
  throw 'Cannot read the repair list from GitHub.'
}
$manifestText = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String(($manifestMeta.content -replace '\s', '')))
$manifest = $manifestText | ConvertFrom-Json
if (-not $manifest.version -or -not $manifest.files) { throw 'The repair list is invalid.' }

function Get-GitHubFileBytes([string]$remotePath) {
  $encoded = (($remotePath -split '/') | ForEach-Object { [System.Uri]::EscapeDataString($_) }) -join '/'
  $uri = "https://api.github.com/repos/thanhnv1493/eumedia-fb-auto-reel/contents/eumedia-update/${encoded}?ref=main"
  $meta = Invoke-RestMethod -Uri $uri -Headers $headers -UseBasicParsing
  if ($meta.encoding -eq 'base64' -and $meta.content) {
    return ,([byte[]][System.Convert]::FromBase64String(($meta.content -replace '\s', '')))
  }
  if ($meta.download_url) {
    $client = New-Object System.Net.WebClient
    try {
      $client.Headers.Add('User-Agent', 'EU-Auto-Recovery')
      return ,([byte[]]$client.DownloadData($meta.download_url))
    } finally { $client.Dispose() }
  }
  throw "GitHub did not return file content: $remotePath"
}

$total = @($manifest.files).Count
$index = 0
foreach ($file in $manifest.files) {
  $index++
  $relativePath = [string]$file.path
  $remotePath = [string]$file.remotePath
  if ([string]::IsNullOrWhiteSpace($remotePath)) { $remotePath = $relativePath }
  if ($relativePath -match '(^|[\\/])\.\.([\\/]|$)' -or $remotePath -match '(^|[\\/])\.\.([\\/]|$)') {
    throw 'Invalid repair path.'
  }
  Write-Host ("[{0}/{1}] Restoring {2}" -f $index, $total, $relativePath)
  $bytes = Get-GitHubFileBytes $remotePath
  $actualHash = ([System.Security.Cryptography.SHA256]::Create().ComputeHash([byte[]]$bytes) | ForEach-Object { $_.ToString('x2') }) -join ''
  if ($actualHash -ne [string]$file.sha256) { throw "File checksum does not match: $relativePath" }
  $target = Join-Path $app ($relativePath -replace '/', '\')
  $directory = Split-Path -Parent $target
  [System.IO.Directory]::CreateDirectory($directory) | Out-Null
  $temporary = "$target.repairing"
  [System.IO.File]::WriteAllBytes($temporary, [byte[]]$bytes)
  Move-Item -LiteralPath $temporary -Destination $target -Force
}

# Logos are retrieved separately because their size exceeds GitHub's inline API limit.
$assetPairs = @(
  @{ Remote = 'public__assets__eu-media-logo.png'; Local = 'assets\eu-media-logo.png' },
  @{ Remote = 'public__assets__eu-media-logo.ico'; Local = 'assets\eu-media-logo.ico' }
)
foreach ($asset in $assetPairs) {
  try {
    $assetTarget = Join-Path $app $asset.Local
    [System.IO.Directory]::CreateDirectory((Split-Path -Parent $assetTarget)) | Out-Null
    [System.IO.File]::WriteAllBytes($assetTarget, [byte[]](Get-GitHubFileBytes $asset.Remote))
  } catch {
    Write-Host 'Logo could not be restored, but EU Auto can still run.' -ForegroundColor Yellow
  }
}

Write-Host ("EU Auto repair complete: version {0}." -f $manifest.version) -ForegroundColor Green
